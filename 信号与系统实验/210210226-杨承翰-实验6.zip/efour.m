clear all
clc
%% 设置原始信号
t = 0 : 0.0005 : 20;
N = 1000;
k = -N : N;
W = k * 2000 / N;
origin = sin(0.8 * pi * t) ;% 原始信号为正弦信号叠加
origin_F = origin * exp(-1i * t' * W) * 0.0005;% 傅里叶变换
origin_F = abs(origin_F);% 取正值
figure;
subplot(3, 2, 1); plot(t, origin); title('原信号时域');
subplot(3, 2, 2); plot(W, origin_F); title('原信号频域');
%% 对原始信号进行2Hz采样率采样
Nsampling = 1/2; % 采样频率
t = 0 : Nsampling : 20;
f_2Hz = sin(0.8 * pi * t); %采样后的信号
F_2Hz = f_2Hz * exp(-1i * t' * W) * Nsampling; % 采样后的傅里叶变换
F_2Hz = abs(F_2Hz);
subplot(3, 2, 3); stem(t, f_2Hz); title('2Hz采样信号时域');
subplot(3, 2, 4); plot(W, F_2Hz); title('2Hz采样信号频域');
%% 对原始信号进行0.8Hz采样率采样
Nsampling = 1.25; % 采样频率
t = 0 : Nsampling : 20;
f_08Hz = sin(0.8 * pi * t); %采样后的信号
F_08Hz = f_08Hz * exp(-1i * t' * W) * Nsampling; % 采样后的傅里叶变换
F_08Hz = abs(F_08Hz);
subplot(3, 2, 5); stem(t, f_08Hz); title('0.8Hz采样信号时域');
subplot(3, 2, 6); plot(W, F_08Hz); title('0.8Hz采样信号频域');
