syms x y t
f2 = (1 - 2*abs(t))*(heaviside(t+0.5) - heaviside(t-0.5));
F2 = fourier(f2,t,y);
figure
fplot(F2,[-50,50],'rx')
hold on;
title("三角脉冲信号频谱1");

f3 = 2^0.5*(heaviside(t+0.25) - heaviside(t-0.25));
F3 = fourier(f3,t,y);
F4 = F3*F3;
fplot(F4,[-50,50],'bo')
hold on;
title("三角脉冲信号频谱2");

F5 = (8*(sin(x/4))^2)/(x^2);
fplot(F5,[-50,50],'k')
title("三角脉冲信号频谱3");
legend('三角脉冲信号频谱1','三角脉冲信号频谱2','三角脉冲信号频谱3')
